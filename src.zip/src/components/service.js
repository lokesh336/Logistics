import '../styles/service.css';

function Service() {
    return (
        <div className='service'>
            <h3><span><img src='../images/icon.png' alt='logo' /></span>Type of Logistics<span><img src='../images/icon.png' alt='logo' /></span></h3>
            <h5>Popular Logistics Services</h5>
            <div className='service-box'>
                <div className='service-img1'data-aos="zoom-out-down">
                    <img src='../images/ser1.jpg' alt='logo' />
                </div>
                <div className='service-img2'data-aos="zoom-out-down">
                    <img src='../images/ser2.jpg' alt='logo' />
                </div>
                <div className='service-img3'data-aos="zoom-out-down">
                    <img src='../images/ser3.jpg' alt='logo' />
                </div>
            </div>

            <div className='service-text'>
                <div className='service-text1'data-aos="zoom-out-down">
                    <div className='service-hr'>
                        <span><hr /></span> <p>Tracking</p>
                    </div>
                    <h6>Transport by Road</h6>
                    <button><i class="fa-solid fa-arrow-right fa-xl"></i></button>
                </div>
                <div className='service-text2'data-aos="zoom-out-down">
                    <div className='service-hr'>
                        <span><hr /></span> <p>Tracking</p>
                    </div>
                    <h6>Safety Garunteed</h6>
                    <button><i class="fa-solid fa-arrow-right fa-xl"></i></button>
                </div>
                <div className='service-text3'data-aos="zoom-out-down">
                    <div className='service-hr'>
                        <span><hr /></span> <p>Tracking</p>
                    </div>
                    <h6>Managing logistics for</h6>
                    <button><i class="fa-solid fa-arrow-right fa-xl"></i></button>
                </div>
            </div>
        </div>
    )
}
export default Service;