import '../styles/price.css';

function Blog(){
    return(
        <div className='blog'>
            <h3><span><img src='../images/icon.png' alt='logo' /></span>Our News from Blog<span>
                <img src='../images/icon.png' alt='logo' /></span></h3>
            <h5>The latest News & Best Blog</h5>
            <div className='blog-box'>
                <div className='blog-box1'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                <img src='../images/blog1.jpg' alt='logo'></img>
                </div>
                <div className='blog-box2'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                    <div className='blog-box2-img'>
                        <img src='../images/blog-icon.jpg' alt='logo'></img>
                        <div className='blog-box2-text'>
                            <h4>By</h4>
                            <p>Website_stock</p>
                        </div>
                        <h6><i class="fa-regular fa-comments"></i><span>(6)Comments</span></h6>
                    </div>
                    <h2>New Additions to our great Metro trucks.</h2>
                    <h1>Read more</h1>
                    <div className='blog-img'>
                     <img src='../images/blog-icon1.jpg' alt='logo'></img>
                    </div>
                </div>
                <div className='blog-box1'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                <img src='../images/blog1.jpg' alt='logo'></img>
                </div>
                <div className='blog-box2'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                    <div className='blog-box2-img'>
                        <img src='../images/blog-icon.jpg' alt='logo'></img>
                        <div className='blog-box2-text'>
                            <h4>By</h4>
                            <p>Website_stock</p>
                        </div>
                        <h6><i class="fa-regular fa-comments"></i><span>(6)Comments</span></h6>
                    </div>
                    <h2>New Additions to our great Metro trucks.</h2>
                    <h1>Read more</h1>
                    <div className='blog-img'>
                     <img src='../images/blog-icon1.jpg' alt='logo'></img>
                    </div>
                </div>
                <div className='blog-box1'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                <img src='../images/blog1.jpg' alt='logo'></img>
                </div>
                <div className='blog-box2'data-aos="fade-up"
     data-aos-anchor-placement="center-center">
                    <div className='blog-box2-img'>
                        <img src='../images/blog-icon.jpg' alt='logo'></img>
                        <div className='blog-box2-text'>
                            <h4>By</h4>
                            <p>Website_stock</p>
                        </div>
                        <h6><i class="fa-regular fa-comments"></i><span>(6)Comments</span></h6>
                    </div>
                    <h2>New Additions to our great Metro trucks.</h2>
                    <h1>Read more</h1>
                    <div className='blog-img'>
                     <img src='../images/blog-icon1.jpg' alt='logo'></img>
                    </div>
                </div>

            </div>
        </div>
    )
}
export default Blog;